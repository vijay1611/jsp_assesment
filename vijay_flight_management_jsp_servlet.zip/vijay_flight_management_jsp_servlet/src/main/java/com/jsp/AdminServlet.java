package com.jsp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("emailid");
		String pass = request.getParameter("password");
		String admin="admin";
		String customer="customer";

		PreparedStatement stmt;
		ResultSet rs;
		Connection con;
		RequestDispatcher rd;
		int count = 0;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/flight", "root", "vijay123");

			String sql = "select * from tbl_Customer";
			stmt = con.prepareStatement(sql);

			rs = stmt.executeQuery();

			while (rs.next()) {
				if (email.equals(rs.getString("email")) && pass.equals(rs.getString("c_password")) && admin.equals(rs.getString("userType")) ) {
					count = 1;
				}
				else if (email.equals(rs.getString("email")) && pass.equals(rs.getString("c_password")) && customer.equals(rs.getString("userType")) ) {
					count = 2;
				}
				
			}

			if (count == 1) {
				request.setAttribute("status", "Login Succesfully.... as " + email);
				rd = request.getRequestDispatcher("admin.jsp");
				rd.forward(request, response);
				count = 0;
			}
			else if(count == 2) {
				request.setAttribute("status", "Login Succesfully.... as " + email);
				rd = request.getRequestDispatcher("user.jsp");
				rd.forward(request, response);
				count = 0;
			}

			else {
				request.setAttribute("status","Failed to Login..");
				rd=request.getRequestDispatcher("Login.jsp");
				rd.forward(request, response);
				}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

