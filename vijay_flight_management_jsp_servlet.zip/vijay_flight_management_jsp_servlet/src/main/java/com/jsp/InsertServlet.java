package com.jsp;

import java.io.IOException; 
import java.io.PrintWriter; 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 



// Import Database Connection Class file 
//import code.DatabaseConnection; 

// Servlet Name 
@WebServlet("/InsertServlet") 
public class InsertServlet extends HttpServlet { 
	private static final long serialVersionUID = 1L; 

	protected void doPost(HttpServletRequest request, 
HttpServletResponse response) 
		throws ServletException, IOException 
	{ 
		try { 

			// Initialize the database 
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/flight", "root", "vijay123");
			
		//	Connection con = DatabaseConnection.initializeDatabase(); 

			// Create a SQL query to insert data into demo table 
			// demo table consists of two columns, so two '?' is used 
			PreparedStatement st = con 
				.prepareStatement("insert  into tbl_Flights(Airlinesname,Source1,Destination,DepartureTime,Arrival,Totalseats,AdultFare,ChildFare,AirportTax)"
						+"  values(?, ?, ?, ?, ?, ?, ?, ?, ?)"); 

			// For the first parameter, 
			// get the data using request object 
			// sets the data to st pointer 
			st.setString(1,request.getParameter("airlines")); 

			// Same for second parameter 
			st.setString(2, request.getParameter("source")); 
			
			st.setString(3,request.getParameter("destination")); 
			st.setDouble(4, Double.valueOf(request.getParameter("departure"))); 
			st.setDouble(5, Double.valueOf(request.getParameter("arrival"))); 
			st.setInt(6, Integer.valueOf(request.getParameter("totalseats"))); 
			st.setInt(7, Integer.valueOf(request.getParameter("adultfare"))); 
			st.setInt(8, Integer.valueOf(request.getParameter("childfare"))); 
			st.setDouble(9, Double.valueOf(request.getParameter("airporttax"))); 

			// Execute the insert command using executeUpdate() 
			// to make changes in database 
			st.executeUpdate(); 

			// Close all the connections 
			st.close(); 
			con.close(); 

			// Get a writer pointer 
			// to display the successful result 
			PrintWriter out = response.getWriter(); 
			out.println("<html><body><b style=color:'green'>Successfully Inserted"
						+ "</b></body></html>"); 
		} 
		catch (Exception e) { 
			e.printStackTrace(); 
		} 
	} 
} 

