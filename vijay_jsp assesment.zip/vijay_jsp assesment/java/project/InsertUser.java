package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class InsertUser
 */
@WebServlet("/InsertUser")
public class InsertUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, 
HttpServletResponse response) 
		throws ServletException, IOException 
	{	try { 

			// Initialize the database 
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/matrimony", "root", "vijay123");
			
		//	Connection con = DatabaseConnection.initializeDatabase(); 

			// Create a SQL query to insert data into demo table 
			// demo table consists of two columns, so two '?' is used 
		
			PreparedStatement ps=con.prepareStatement("insert into users values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			

			ps.setString(1,request.getParameter("first_name"));
			ps.setString(2,request.getParameter("last_name"));
			ps.setString(3,request.getParameter("age"));
			ps.setString(4,request.getParameter("gender"));
			
			ps.setString(5,request.getParameter("mobileNumber"));
			ps.setString(6,request.getParameter("email"));
			ps.setString(7,request.getParameter("mother_tongue"));
			ps.setString(8,request.getParameter("religion"));
			ps.setString(9,request.getParameter("caste"));
			ps.setString(10,request.getParameter("occupation"));
			ps.setString(11,request.getParameter("state"));
			ps.setString(12,request.getParameter("district"));
			ps.setString(13,request.getParameter("address"));
			ps.setString(14,request.getParameter("password"));

			ps.setString(15,request.getParameter("photo"));
			
			ps.executeUpdate();
			response.sendRedirect("signup.jsp?msg=valid");
			
			

		}catch(Exception e){
			System.out.println(e);
			response.sendRedirect("signup.jsp?msg=invalid");
			}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
}
