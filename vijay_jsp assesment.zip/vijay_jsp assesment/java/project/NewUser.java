package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class NewUser
 */
@MultipartConfig
@WebServlet("/NewUser")
public class NewUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String first_name=request.getParameter("first_name");
		String last_name=request.getParameter("last_name");
		String age=request.getParameter("age");
		String gender=request.getParameter("gender");
		String mobileNumber=request.getParameter("mobileNumber");
		String email=request.getParameter("email");
		String mother_tongue=request.getParameter("mother_tongue");
		String religion=request.getParameter("religion");
		String caste=request.getParameter("caste");
		String occupation=request.getParameter("occupation");
		String state=request.getParameter("state");
		String district=request.getParameter("district");
		String address=request.getParameter("address");
		String password=request.getParameter("password");
		String status=request.getParameter("status");
		String payment="";
		Part file=request.getPart("photo");
		String imageFileName=file.getSubmittedFileName();
		String uploadPath="C:/Users/ELCOT/eclipse_work/matrimony/src/main/webapp/images1/"+imageFileName;

		FileOutputStream fos=new FileOutputStream(uploadPath);
		InputStream is=file.getInputStream();

		byte[] data=new byte[is.available()];
		is.read(data);
		fos.write(data);
		fos.close();

		try{
				Connection con=ConnectionProvider.getCon();
			PreparedStatement ps=con.prepareStatement("insert into users(first_name,last_name,age,gender,mobileNumber,email,mother_tongue,religion,caste,occupation,state,district,address,password,photo,status,payment) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1,first_name);
			ps.setString(2,last_name);
			ps.setString(3,age);
			ps.setString(4,gender);
			
			ps.setString(5,mobileNumber);
			ps.setString(6,email);
			ps.setString(7,mother_tongue);
			ps.setString(8,religion);
			ps.setString(9,caste);
			ps.setString(10,occupation);
			ps.setString(11,state);
			ps.setString(12,district);
			ps.setString(13,address);
			ps.setString(14,password);

			ps.setString(15,imageFileName);
			ps.setString(16,status);
			ps.setString(17,payment);
			ps.executeUpdate();
			response.sendRedirect("signup.jsp?msg=valid");
			
			

		}catch(Exception e){
			System.out.println(e);
			response.sendRedirect("signup.jsp?msg=invalid");
			}
	}

}
