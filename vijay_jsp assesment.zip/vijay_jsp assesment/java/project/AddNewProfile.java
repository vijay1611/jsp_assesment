package project;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class AddNewProfile
 */
@MultipartConfig
@WebServlet("/AddNewProfile")
public class AddNewProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddNewProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		
		String name=request.getParameter("name");
		String gender=request.getParameter("gender");
		String age=request.getParameter("age");
		String city=request.getParameter("city");
		String active=request.getParameter("active");
		Part file=request.getPart("photo");
		String imageFileName=file.getSubmittedFileName();
		String uploadPath="C:/Users/ELCOT\\eclipse_work/matrimony/src/main/webapp/images/"+imageFileName;
		
		FileOutputStream fos=new FileOutputStream(uploadPath);
		InputStream is=file.getInputStream();
		
		byte[] data=new byte[is.available()];
		is.read(data);
		fos.write(data);
		fos.close();
		
		try{
			Connection con=ConnectionProvider.getCon();
			PreparedStatement ps=con.prepareStatement("insert into profile2(photo,name,gender,age,city,active) values(?,?,?,?,?,?)");
			
			ps.setString(1,imageFileName);
			ps.setString(2,name);
			ps.setString(3,gender);
			ps.setString(4,age);
			ps.setString(5,city);
			ps.setString(6,active);
			
			ps.executeUpdate();
			response.sendRedirect("./admin/addNewProfile.jsp?msg=done");
			
			

		}catch(Exception e){
			System.out.println(e);
			response.sendRedirect("./admin/addNewProfile.jsp?msg=wrong");
			}
		
		
	}

}



















